__author__ = 'bliss'

import os, sys

abspath = os.path.abspath('../')
sys.path.append(abspath)