# error code description

## start with 1
means common exception
10000 : parameter exception
10080 : email that used to register has been taken
10081 : nickname that used to register has been taken

## start with 2
means user exception
