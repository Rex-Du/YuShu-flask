# -*- coding:utf-8 -*-
__author__ = 'bliss'

from flask.ext.cache import Cache

# flask-cache 全局引用
cache = Cache()